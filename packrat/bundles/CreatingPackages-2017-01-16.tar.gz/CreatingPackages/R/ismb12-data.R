#' Twiter data for 2012
#'
#' Twiter Data to generate ranking
#'
#' @docType data
#'
#' @usage load("./data/ismb2012.RData")
#'
#' @keywords datasets
#'
#'
"ismb12"
