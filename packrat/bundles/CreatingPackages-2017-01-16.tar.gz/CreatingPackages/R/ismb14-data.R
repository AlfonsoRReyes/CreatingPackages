#' Twiter data for 2014
#'
#' Twiter Data to generate ranking
#'
#' @docType data
#'
#' @keywords datasets
#'
#'
"ismb14"
